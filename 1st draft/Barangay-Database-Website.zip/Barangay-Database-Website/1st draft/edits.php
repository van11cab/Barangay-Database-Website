<?php  
	

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Admin Page</title>
</head>
<body>
	
</body>
</html>